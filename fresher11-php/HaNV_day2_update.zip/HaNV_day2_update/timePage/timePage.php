<?php
    /**thời gian chỉnh sửa lần cuối cùng của trang hiện tại */
    echo "Last modified: " . date ("F d Y H:i:s.", getlastmod())."<br>";